<?php $__env->startSection('title', 'Laporan Absensi'); ?>
<?php $__env->startSection('page-heading', 'Laporan Absensi'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col">
                <form action="<?php echo e(route('absensi.print')); ?>" method="POST" target="_blank">
                    <?php echo csrf_field(); ?>
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Laporan Absensi</h5>
                            <div class="form-group">
                                <label for="mulai_dari">Mulai Dari:</label>
                                <input type="date" class="form-control" name="mulai_dari">
                            </div>
                            <div class="form-group">
                                <label for="sampai_dengan">Sampai Dengan:</label>
                                <input type="date" class="form-control" name="sampai_dengan">
                            </div>
                            <button class="form-control btn btn-primary">Print</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.partials.partials-dashboard.partials-dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\lavacheese\resources\views/absensi/laporanabsensi.blade.php ENDPATH**/ ?>
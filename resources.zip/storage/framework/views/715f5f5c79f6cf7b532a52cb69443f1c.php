<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
<meta http-equiv="X-UA-Compatible" content="IE=edge" />

<link rel="stylesheet" href="https://www.amcharts.com/lib/3/plugins/export/export.css" type="text/css" media="all" />

<link href="<?php echo e(asset('dashboardthemeassets/vendor/fontawesome-free/css/all.min.css')); ?>" rel="stylesheet"
    type="text/css">
<link href="<?php echo e(asset('dashboardthemeassets/css/sb-admin-2.css')); ?>" rel="stylesheet">
<!-- select2js -->
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/select2-bootstrap-5-theme@1.3.0/dist/select2-bootstrap-5-theme.rtl.min.css" />
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" type="text/css">

<link rel="stylesheet" href="https://unpkg.com/trix@2.0.0/dist/trix.css">

<?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

<?php /**PATH C:\laragon\www\lavacheese\resources\views/layouts/partials/partials-css/dashboard-css.blade.php ENDPATH**/ ?>
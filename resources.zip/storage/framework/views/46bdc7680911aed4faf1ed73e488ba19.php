<?php $__env->startSection('title', 'Absensi'); ?>
<?php $__env->startSection('page-heading', 'Data Absensi'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if( Auth::user()->karyawan->first()?->jabatan?->nama!='Administrator'): ?>

        <div class="card">
            <div class="card-body text-center">
                <h3>Absensi Hari Ini </h3>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($sudah_absen): ?>
                    <p class="mt-2">
                        Anda sudah absen hari ini. Selamat Bekerja!
                    </p>
                <?php else: ?>
                    <p class="mt-2">
                        Silakan lakukan absensi untuk tanggal
                        <strong><?php echo e(\Carbon\Carbon::now()->translatedFormat('d F Y')); ?></strong>.
                    </p>
                    <a href="<?php echo e(route('absensi.create')); ?>" class="btn btn-primary">Absen Disini</a>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>


            </div>
        </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <div class="card mt-5">
            <div class="card-body">
                <div class="table-responsive">
                    <div class="table table-hover table-stripped">
                        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('absensi.absensi-index');

$key = null;

$key ??= \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::generateKey('lw-943202762-0', null);

$__html = app('livewire')->mount($__name, $__params, $key);

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.partials.partials-dashboard.partials-dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\lavacheese\resources\views/absensi/index.blade.php ENDPATH**/ ?>
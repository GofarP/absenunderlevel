<div>
    <div class="table-responsive">
        <div class="float-right mb-3">
            <input type="text" wire:model.live.debounce.300ms="search" class="form-control" placeholder="Cari...">
        </div>
        <table class="table table-bordered" style="color: black;">
            <thead>
                <th style="border: 1px solid; color: black">No</th>
                <th style="border: 1px solid; color: black;">Nama</th>
                <th style="border: 1px solid; color: black;">Status Absensi</th>
                <th style="border: 1px solid; color: black;">Jenis Absensi</th>
                <th style="border: 1px solid; color: black;">Shift</th>
                <th style="border: 1px solid; color: black;">Waktu Absen</th>
                <th style="border: 1px solid; color: black;">Foto</th>
                <th style="border: 1px solid; color: black;">Action</th>
            </thead>
            <tbody>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $data_absensi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td style="border: 1px solid; color: black;"><?php echo e($loop->iteration); ?></td>
                        <td style="border: 1px solid; color: black;"><?php echo e($item->users->name ?? '-'); ?></td>
                        <td style="border: 1px solid; color: black;"><?php echo e($item->statusabsensi->nama ?? '-'); ?></td>
                        <td style="border: 1px solid; color: black;"><?php echo e($item->jenisabsensi->nama ?? '-'); ?></td>
                        <td style="border: 1px solid; color: black;"><?php echo e($item->shift->nama ?? '-'); ?></td>
                        <td style="border: 1px solid; color: black;">
                            <?php echo e(\Carbon\Carbon::parse($item->created_at)->format('d-m-Y H:i')); ?></td>
                        <td style="border: 1px solid; color: black;">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($item->foto != null): ?>
                                <img src="<?php echo e(asset('foto_absensi/' . $item->foto)); ?>" width="100" height="100"
                                    alt="">
                            <?php else: ?>
                                <img src="<?php echo e(asset('foto_karyawan/images.png')); ?>" class="img-fluid" alt="">
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </td>

                        <td style="border: 1px solid; color: black;">
                            <div class="d-flex">

                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(Auth::user()->karyawan->first()?->jabatan?->nama == 'Administrator'): ?>
                                    <a href="<?php echo e(route('absensi.edit', $item->id)); ?>" class="btn btn-warning">Edit</a>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                                <form action="<?php echo e(route('absensi.destroy', $item->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger"
                                        onclick="return confirm('Apakah Anda Ingin Menghapus Data Ini')">Hapus</button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="8" class="text-center" style="border: 1px solid; color: black;">Data Tidak
                            Tersedia Atau Masih Kosong</td>
                    </tr>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </tbody>
        </table>
        <div class="float-right mt-3">
            <div class="pagination pagination-dark">
                <?php echo e($data_absensi->links()); ?>

            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\lavacheese\resources\views/livewire/absensi/absensi-index.blade.php ENDPATH**/ ?>
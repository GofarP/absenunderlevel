<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('page-heading', 'Selamat Datang ' . Auth::user()->name); ?>
<?php $__env->startSection('content'); ?>
    <?php
        $jabatan = Auth::user()->karyawan->first()?->jabatan?->nama;
    ?>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($jabatan !== 'Administrator'): ?>
        <!-- Earnings (Monthly) Card Example -->
        <div class="card shadow mb-4 w-100">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Absen Bulan
                    <?php echo e(\Carbon\Carbon::now()->translatedFormat('F Y')); ?></h6>
            </div>
            <div class="card-body">
                <div class="row">

                    <!-- Total Masuk Bulan -->
                    <div class="col-12 mb-4">
                        <div class="card border-left-success shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                            Jumlah Masuk Bulan <?php echo e(\Carbon\Carbon::now()->translatedFormat('F')); ?>

                                        </div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800">
                                            <?php echo e($jumlah_masuk_bulan_ini); ?>

                                        </div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-calendar-alt fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>



                </div>
            </div>
            <!-- End Card Body -->
        </div> <!-- End Main Card -->

        <div class="card shadow mb-4 w-100">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Absen Bulan
                    <?php echo e(\Carbon\Carbon::now()->subMonth()->translatedFormat('F Y')); ?></h6>
            </div>
            <div class="card-body">
                <div class="row">                         <div class="card border-left-success shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                            Jumlah Masuk Bulan
                                            <?php echo e(\Carbon\Carbon::now()->subMonth()->translatedFormat('F')); ?>

                                        </div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e($jumlah_masuk_bulan_lalu); ?>

                                        </div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-calendar-alt fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                  
                </div>
            </div> <!-- End Card Body -->
        </div> <!-- End Main Card -->
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.partials.partials-dashboard.partials-dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\lavacheese\resources\views/dashboard/index.blade.php ENDPATH**/ ?>
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class JenisAbsensi extends Model
{
    protected $fillable=[
        "nama"
    ];
}
